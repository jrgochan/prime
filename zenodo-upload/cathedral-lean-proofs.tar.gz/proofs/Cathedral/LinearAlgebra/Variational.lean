/-
  Cathedral/LinearAlgebra/Variational.lean

  ## The Variational Principle (Abstract)

  For a positive semidefinite Hermitian matrix G with invertible determinant,
  and any vectors b, v:
    d² ≤ 1 - 2bᵀv + vᵀGv  (variational upper bound)

  And in Rayleigh quotient form:
    (bᵀv)² / (vᵀGv) ≤ bᵀG⁻¹b

  Contains:
  - realQuadForm: the quadratic form xᵀAx
  - variational_bound: the abstract variational principle
  - cauchy_schwarz_quadform: Cauchy-Schwarz for PSD matrices
  - posSemidef_pos_of_ne_zero: PSD + invertible → PD behavior

  All theorems: PROVED, 0 axioms.

  Created: April 10, 2026 (Reintegration)
  Refactored: April 11, 2026 (Split into Variational/SchurComplement/Sylvester)
-/

import Mathlib.LinearAlgebra.Matrix.DotProduct
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Data.Matrix.Basic

noncomputable section
open Matrix Finset

namespace Cathedral.Variational

variable {n : ℕ}

-- ════════════════════════════════════════════════
-- SECTION 1: ABSTRACT QUADRATIC FORM TOOLS
-- ════════════════════════════════════════════════

/-- The real quadratic form xᵀAx. -/
def realQuadForm (A : Matrix (Fin n) (Fin n) ℝ) (x : Fin n → ℝ) : ℝ :=
  dotProduct x (A.mulVec x)

-- ════════════════════════════════════════════════
-- SECTION 2: THE VARIATIONAL BOUND (from QuadFormBridge)
-- ════════════════════════════════════════════════

/-- **THE ABSTRACT VARIATIONAL PRINCIPLE.**

    For a positive semidefinite Hermitian matrix G with invertible determinant,
    and ANY test vector v:

      bᵀG⁻¹b ≥ 2·bᵀv - vᵀGv

    Proof: expand (v - G⁻¹b)ᵀG(v - G⁻¹b) ≥ 0.

    Adapted from QuadFormBridge.nbDistSq_le_test_vector (PROVED). -/
theorem variational_bound
    (G : Matrix (Fin n) (Fin n) ℝ) (b v : Fin n → ℝ)
    (hH : G.IsHermitian) (hPSD : G.PosSemidef)
    (h_unit : IsUnit G.det) :
    realQuadForm G v - 2 * dotProduct b v +
      dotProduct b (G⁻¹.mulVec b) ≥ 0 := by
  set c := G⁻¹.mulVec b with hc_def
  have h_Gc : G.mulVec c = b := by
    rw [hc_def, Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv _ h_unit,
        Matrix.one_mulVec]
  -- Key: (v - c)ᵀ G (v - c) ≥ 0 by PSD
  have h_psd := hPSD.dotProduct_mulVec_nonneg (v - c)
  simp only [star_trivial] at h_psd
  -- Expand: (v-c)ᵀG(v-c) = vᵀGv - 2·vᵀGc + cᵀGc
  have h_expand : dotProduct (v - c) (G.mulVec (v - c)) =
      realQuadForm G v - 2 * dotProduct v (G.mulVec c) +
      realQuadForm G c := by
    unfold realQuadForm
    simp only [Matrix.mulVec_sub, sub_dotProduct, dotProduct_sub]
    have h_sym : dotProduct c (G.mulVec v) = dotProduct v (G.mulVec c) := by
      simp only [dotProduct, Matrix.mulVec] at *
      simp_rw [Finset.mul_sum]
      rw [Finset.sum_comm]
      congr 1; ext j; congr 1; ext i
      have hij : G i j = G j i := by
        have := congr_fun (congr_fun hH i) j
        simp [Matrix.conjTranspose_apply, star_trivial] at this
        exact this.symm
      ring_nf; rw [hij]; ring
    linarith
  -- Substitute Gc = b into the expansion
  rw [h_Gc] at h_expand
  have h_cb : realQuadForm G c = dotProduct b c := by
    unfold realQuadForm; rw [h_Gc]; exact dotProduct_comm c b
  have h_bc : dotProduct b c = dotProduct b (G⁻¹.mulVec b) := by
    rw [hc_def]
  have h_vb : dotProduct v b = dotProduct b v := dotProduct_comm v b
  rw [h_cb, h_bc, h_vb] at h_expand
  linarith

-- ════════════════════════════════════════════════
-- SECTION 3: CAUCHY-SCHWARZ FOR QUADRATIC FORMS
-- ════════════════════════════════════════════════

/-- **Cauchy-Schwarz for positive semidefinite matrices.**

    (bᵀv)² ≤ (vᵀGv) · (bᵀG⁻¹b)

    Proof: apply PSD to the vector w = (vᵀGv)·G⁻¹b - (bᵀv)·v.
    Then wᵀGw = (vᵀGv)·((vᵀGv)·(bᵀG⁻¹b) - (bᵀv)²) ≥ 0.
    Since vᵀGv > 0, divide to get the result. -/
theorem cauchy_schwarz_quadform
    (G : Matrix (Fin n) (Fin n) ℝ) (b v : Fin n → ℝ)
    (hH : G.IsHermitian) (hPSD : G.PosSemidef)
    (h_unit : IsUnit G.det)
    (hv_pos : realQuadForm G v > 0) :
    (dotProduct b v) ^ 2 ≤
    realQuadForm G v * dotProduct b (G⁻¹.mulVec b) := by
  -- Use the variational bound: vᵀGv - 2bᵀv + bᵀG⁻¹b ≥ 0
  have h_var := variational_bound G b v hH hPSD h_unit
  -- Apply PSD to the scaled vector: (bᵀv)·G⁻¹b - v
  set c := G⁻¹.mulVec b
  have h_Gc : G.mulVec c = b := by
    rw [Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv _ h_unit, Matrix.one_mulVec]
  -- PSD applied to w = (bᵀv)·c - v:
  have h_cGv : dotProduct c (G.mulVec v) = dotProduct v (G.mulVec c) := by
    simp only [dotProduct, Matrix.mulVec] at *
    simp_rw [Finset.mul_sum]
    rw [Finset.sum_comm]
    congr 1; ext j; congr 1; ext i
    have hij : G i j = G j i := by
      have := congr_fun (congr_fun hH i) j
      simp [Matrix.conjTranspose_apply, star_trivial] at this
      exact this.symm
    ring_nf; rw [hij]; ring
  -- Apply PSD to w = a·c - x·v where a = vᵀGv, x = bᵀv
  have h_w2 := hPSD.dotProduct_mulVec_nonneg
    (realQuadForm G v • c - dotProduct b v • v)
  simp only [star_trivial] at h_w2
  have h_expand_w2 : dotProduct (realQuadForm G v • c - dotProduct b v • v)
      (G.mulVec (realQuadForm G v • c - dotProduct b v • v)) =
      (realQuadForm G v)^2 * dotProduct c b -
      2 * realQuadForm G v * dotProduct b v * dotProduct v b +
      (dotProduct b v)^2 * realQuadForm G v := by
    unfold realQuadForm
    simp only [Matrix.mulVec_sub, Matrix.mulVec_smul,
      sub_dotProduct, dotProduct_sub, smul_dotProduct, dotProduct_smul]
    rw [h_Gc, h_cGv, h_Gc]
    simp [smul_eq_mul]; ring
  have h_comm : dotProduct v b = dotProduct b v := dotProduct_comm v b
  have h_cb : dotProduct c b = dotProduct b c := dotProduct_comm c b
  rw [h_expand_w2, h_comm, h_cb] at h_w2
  nlinarith [hv_pos]

/-- For a PSD Hermitian matrix with invertible determinant, xᵀGx > 0 for any x ≠ 0.
    This is the key bridge from PSD + invertible to PosDef behavior on (Fin n → ℝ).
    Proof: xᵀGx = 0 implies Gx = 0 (by PSD polarization), but G invertible means
    Gx = 0 → x = 0, contradicting x ≠ 0. -/
theorem posSemidef_pos_of_ne_zero {n : ℕ} (G : Matrix (Fin n) (Fin n) ℝ)
    (hH : G.IsHermitian) (hPSD : G.PosSemidef) (h_unit : IsUnit G.det)
    (x : Fin n → ℝ) (hx : x ≠ 0) :
    dotProduct x (G.mulVec x) > 0 := by
  have h_nn := hPSD.dotProduct_mulVec_nonneg x
  simp only [star_trivial] at h_nn
  rcases lt_or_eq_of_le h_nn with h_pos | h_eq
  · exact h_pos
  · exfalso
    -- xᵀGx = 0. Show Gx = 0 by showing (Gx)ᵢ = 0 for each i.
    suffices h_Gx : G.mulVec x = 0 by
      have h_isUnit : IsUnit G := G.isUnit_iff_isUnit_det.mpr h_unit
      have h_inj := Matrix.mulVec_injective_of_isUnit h_isUnit
      exact hx (h_inj (by rw [h_Gx, Matrix.mulVec_zero]))
    funext i
    simp only [Pi.zero_apply]
    by_contra h_ne_i
    -- Define standard basis vector explicitly
    let ei : Fin n → ℝ := Pi.single i 1
    -- PSD on (x + t·eᵢ) for all t
    have h_psd_t := fun (t : ℝ) => hPSD.dotProduct_mulVec_nonneg (x + t • ei)
    simp only [star_trivial] at h_psd_t
    -- Expand (x + t·eᵢ)ᵀG(x + t·eᵢ)
    have h_expand : ∀ t : ℝ,
        dotProduct (x + t • ei) (G.mulVec (x + t • ei)) =
        dotProduct x (G.mulVec x) +
        2 * t * dotProduct ei (G.mulVec x) +
        t ^ 2 * dotProduct ei (G.mulVec ei) := by
      intro t
      simp only [Matrix.mulVec_add, Matrix.mulVec_smul,
        add_dotProduct, dotProduct_add, smul_dotProduct, dotProduct_smul]
      have h_comm : dotProduct x (G.mulVec ei) =
          dotProduct ei (G.mulVec x) := by
        simp only [dotProduct, Matrix.mulVec] at *
        simp_rw [Finset.mul_sum]
        rw [Finset.sum_comm]
        congr 1; ext j; congr 1; ext k
        have hkj : G k j = G j k := by
          have := congr_fun (congr_fun hH k) j
          simp [Matrix.conjTranspose_apply, star_trivial] at this
          exact this.symm
        ring_nf; rw [hkj]; ring
      rw [h_comm]; simp [smul_eq_mul]; ring
    -- eᵢᵀGx = (Gx)ᵢ
    have h_dot_ei : dotProduct ei (G.mulVec x) = (G.mulVec x) i := by
      unfold dotProduct ei
      rw [Finset.sum_eq_single i]
      · simp [Pi.single]
      · intro j _ hji; simp [Pi.single, hji]
      · intro h; exact absurd (Finset.mem_univ i) h
    -- (Gx)ᵢ ≠ 0
    have h_Gx_ne : (G.mulVec x) i ≠ 0 := h_ne_i
    -- eᵢᵀGeᵢ ≥ 0
    have h_Gii := hPSD.dotProduct_mulVec_nonneg ei
    simp only [star_trivial] at h_Gii
    -- From PSD: ∀ t, 0 + 2t·c + t²·a ≥ 0 (where c = (Gx)ᵢ, a = eᵢᵀGeᵢ)
    set c := (G.mulVec x) i with hc_def
    set a := dotProduct ei (G.mulVec ei) with ha_def
    -- Every t satisfies the bound
    have h_bound : ∀ t : ℝ, 0 ≤ 2 * t * c + t ^ 2 * a := by
      intro t
      have := h_psd_t t
      rw [h_expand t, ← h_eq, h_dot_ei] at this
      linarith
    -- Discriminant argument: if a = 0 then 2tc ≥ 0 for all t → c = 0
    -- If a > 0: min at t = -c/a gives -c²/a ≥ 0 → c = 0
    rcases eq_or_ne a 0 with ha0 | ha_ne
    · -- a = 0: bound is 2tc ≥ 0 for all t
      have h1 := h_bound 1
      have h2 := h_bound (-1)
      rw [ha0] at h1 h2; simp at h1 h2
      have hc_le : c ≤ 0 := by linarith
      have hc_ge : c ≥ 0 := by linarith
      exact h_Gx_ne (le_antisymm hc_le hc_ge)
    · -- a > 0 by PSD
      have ha_pos : a > 0 := lt_of_le_of_ne h_Gii (Ne.symm ha_ne)
      have h_at_min := h_bound (-c / a)
      have h_c_sq : c ^ 2 ≤ 0 := by
        have h_base := h_at_min
        have h_simp : 2 * (-c / a) * c + (-c / a) ^ 2 * a = -(c ^ 2) / a := by
          field_simp; ring
        rw [h_simp] at h_base
        have h_neg_div : -(c ^ 2) / a ≥ 0 := h_base
        have h_neg : -(c ^ 2) ≥ 0 := nonneg_of_mul_nonneg_left
          (by rwa [div_eq_mul_inv, mul_comm] at h_neg_div) (inv_pos.mpr ha_pos)
        linarith
      exact h_Gx_ne (by nlinarith [sq_nonneg c])

end Cathedral.Variational
