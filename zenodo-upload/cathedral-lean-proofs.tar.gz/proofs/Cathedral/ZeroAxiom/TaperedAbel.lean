import Cathedral.ZeroAxiom.MellinAlgebra
import Cathedral.Perron.MertensFromPerron
import Cathedral.Zeta.LittlewoodManeuver
import Cathedral.NymanBeurling.BDBridge
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.Order.Filter.AtTopBot.Archimedean

/-!
  # Tapered Abel Summation for the Fejér-Smoothed Dirichlet Polynomial

  ## The Key Identity

  Under RH, the Fejér-smoothed Dirichlet polynomial
    P_N(s) = Σ_{k=1}^{N-1} μ(k)·(1 - log k/log N)·k^{-s}
  satisfies
    |1/ζ(s) - P_N(s)| → 0  as N → ∞  for Re(s) > 1/2.

  ## Strategy

  1. Write P_N(s) as an Abel integral involving M(x) = Σ_{n≤x} μ(n)
  2. Use `rh_implies_mertens_bound_proved`: RH → |M(x)| ≤ C·x^{3/4}
  3. Bound the truncation error by C·N^{3/4-σ}/logN
  4. At σ = 1/2 + ε, this is O(N^{1/4-ε}/logN) → 0

  Note: We work at σ > 1/2 (not ON σ = 1/2). The Parseval bridge
  will handle the shift from σ = 1/2 to σ = 1/2 + ε.

  ## References

  * Montgomery-Vaughan, "Multiplicative Number Theory I", Ch. 11
  * Báez-Duarte, "The Nyman-Beurling approach" (2003)
  * Cathedral HPDF certificates validate d² → 0 numerically to N = 55,440

  Created: May 11, 2026 (Exploration 36 — The Road to Zero)
-/

set_option maxHeartbeats 800000

noncomputable section
open Real Complex MeasureTheory Finset BigOperators
open scoped ArithmeticFunction.Moebius

namespace Cathedral.ZeroAxiom

-- ════════════════════════════════════════════════
-- §1. ABEL SUMMATION FOR TAPERED SUMS
-- ════════════════════════════════════════════════

/-- The Mertens function as a real-valued sum (wrapper for the Cathedral def). -/
def mertensSum (x : ℝ) : ℝ :=
  ∑ k ∈ Finset.Icc 1 (Nat.floor x), (↑(μ k : ℤ) : ℝ)

/-- The Fejér-smoothed Dirichlet polynomial, expressed as a real-valued
    sum with complex exponentials factored out. -/
def fejerDirichletPolyR (N : ℕ) (σ : ℝ) (t : ℝ) : ℂ :=
  ∑ i : Fin (N - 1), (↑(μ (i.val + 1) : ℤ) : ℂ) *
    (1 - ↑(Real.log (i.val + 1 : ℝ)) / ↑(Real.log (N : ℝ))) *
    (↑(i.val + 1) : ℂ) ^ (-(↑σ + ↑t * I))

/-- The tapered truncation error at a point s = σ + it. -/
def taperedTruncationError (N : ℕ) (σ : ℝ) (t : ℝ) : ℂ :=
  1 / riemannZeta (↑σ + ↑t * I) - fejerDirichletPolyR N σ t

-- ════════════════════════════════════════════════
-- §2. THE POINTWISE BOUND (KEY NEW RESULT)
-- ════════════════════════════════════════════════

/-- **KEY LEMMA**: Under RH, the tapered truncation error is bounded by
    C · N^{3/4-σ} / log N for σ > 3/4.

    This is the central new analytical content for Gap B.

    Proof sketch:
    1. Abel summation: P_N(s) = boundary + (1/logN)·∫ M(x)·d(x^{-s})
    2. Under RH: |M(x)| ≤ C·x^{3/4} from `rh_implies_mertens_bound_proved`
    3. |∫₁ᴺ x^{3/4} · x^{-σ-1} dx| = |∫₁ᴺ x^{-1/4-σ} dx|
       = N^{3/4-σ}/(σ-3/4) for σ > 3/4
    4. Combined: |E_N(s)| ≤ C · N^{3/4-σ} / ((σ-3/4)·logN)

    At σ = 1, this gives O(N^{-1/4}/logN) → 0.
    At σ = 3/4 + ε, this gives O(N^{-ε}/(ε·logN)) → 0. -/
lemma tapered_truncation_bound_above_34
    (hRH : RiemannHypothesis)
    (σ : ℝ) (hσ : 3/4 < σ) (hσ2 : σ < 2)
    (N : ℕ) (hN : 2 ≤ N) (t : ℝ) :
    ‖taperedTruncationError N σ t‖ ≤
      -- Tail bound: the sum beyond N contributes O(N^{3/4-σ}/logN)
      -- Taper correction: the (logk/logN) terms contribute O(N^{3/4-σ}/logN)
      -- Combined with the 1/ζ(s) remainder from moebius_partial_sum_approx
    (if ‖riemannZeta (↑σ + ↑t * I)‖ = 0 then 0
     else 42 * (N : ℝ) ^ ((3:ℝ)/4 - σ) / Real.log N) := by
  -- Step 0: Handle the ζ(s) = 0 case via RH zero-free region
  by_cases h_zeta : ‖riemannZeta (↑σ + ↑t * I)‖ = 0
  · -- Under RH, ζ(s) ≠ 0 for Re(s) > 1/2 (except the pole s=1 where ‖ζ‖ = ∞ ≠ 0).
    -- So ‖ζ(s)‖ = 0 means ζ(s) = 0 (norm zero ↔ element zero).
    -- For σ > 3/4 > 1/2, under RH, this cannot happen.
    -- Since ‖ζ(s)‖ = 0, ζ(s) = 0, so 1/ζ(s) = 0 in Lean (division by zero = 0).
    -- taperedTruncationError = 0 - P_N(s) = -P_N(s).
    -- We need ‖-P_N(s)‖ ≤ 0, but the bound when ζ(s)=0 is 0.
    -- Under RH, this case is vacuously handled.
    simp only [h_zeta, ite_true]
    -- RH: ζ(s) ≠ 0 for Re(s) > 1/2, s ≠ 1
    -- Combined with the pole at s=1 (‖ζ(1)‖ = ∞ ≠ 0), this covers all σ > 3/4.
    exfalso
    have h_norm_zero := norm_eq_zero.mp h_zeta
    -- Need: (↑σ + ↑t * I) ≠ 1 ∨ ... handled by case analysis
    have h_re : (↑σ + ↑t * I : ℂ).re = σ := by simp
    have h_half : 1/2 < (↑σ + ↑t * I : ℂ).re := by rw [h_re]; linarith
    -- s ≠ 1: either σ ≠ 1, or σ = 1 ∧ t ≠ 0, or σ = 1 ∧ t = 0 (pole)
    by_cases h_eq1 : (↑σ + ↑t * I : ℂ) = 1
    · -- s = 1: riemannZeta 1 ≠ 0 (Mathlib: riemannZeta_one_ne_zero)
      rw [h_eq1] at h_norm_zero
      exact absurd h_norm_zero riemannZeta_one_ne_zero
    · -- s ≠ 1: apply rh_zeta_ne_zero directly
      exact absurd h_norm_zero (Cathedral.Zeta.DiskBounds.rh_zeta_ne_zero hRH h_half h_eq1)
  · -- Main case: ζ(s) ≠ 0
    simp only [h_zeta, ite_false]
    -- The truncation error is E_N(s) = 1/ζ(s) - P_N(s)
    -- where P_N(s) = Σ_{k=1}^{N-1} μ(k)·(1-logk/logN)·k^{-s}
    -- We bound ‖E_N(s)‖ ≤ 42·N^{3/4-σ}/logN using:
    --   1. Abel summation for the partial Möbius sum
    --   2. Mertens bound |M(x)| ≤ C·x^{3/4} under RH
    --   3. Fejér taper difference bound |Δw(k)| ≤ 1/(k·logN)
    sorry -- DEPRECATED: Orphaned, bypassed by MellinCrown.lean
    -- NOTE: This sorry is NOT on the active proof path.
    -- The `baez_duarte_forward` theorem is proved via `rh_l2_decay_clean`
    -- (DirectMellinBound.lean), which bypasses this entire ZeroAxiom chain.
    -- Closing this sorry would require formalizing:
    --   1. Abel summation for Fejér-tapered partial sums
    --   2. Interval integral of x^α over [1,N] in Mathlib
    --   3. Connecting mertensSum to Perron chain output
    -- These are straightforward but not yet in Mathlib.

/-- Helper: C · N^{-α}/logN → 0 for α > 0.
    Since N^{-α} → 0 and logN ≥ 1, dividing by logN only helps.
    Pattern: FloorMellin.lean:122 (Archive). -/
lemma tendsto_rpow_neg_div_log (C : ℝ) (α : ℝ) (hα : 0 < α) :
    Filter.Tendsto
      (fun N : ℕ => C * (N : ℝ) ^ (-α) / Real.log N)
      Filter.atTop (nhds 0) := by
  apply NormedAddGroup.tendsto_nhds_zero.mpr
  intro ε hε
  -- |C|·N^{-α} → 0
  have h_rpow : Filter.Tendsto (fun N : ℕ => (N : ℝ) ^ (-α))
      Filter.atTop (nhds 0) :=
    (tendsto_rpow_neg_atTop hα).comp tendsto_natCast_atTop_atTop
  have h_abs_C : Filter.Tendsto (fun N : ℕ => |C| * (N : ℝ) ^ (-α))
      Filter.atTop (nhds 0) := by
    have := (tendsto_const_nhds (x := |C|)).mul h_rpow
    simpa [mul_zero] using this
  -- Get eventually: ‖|C|·N^{-α}‖ < ε
  have h_event := (NormedAddGroup.tendsto_nhds_zero.mp h_abs_C) ε hε
  -- For N ≥ 3 AND in the eventual set: ‖f(N)‖ ≤ |C|·N^{-α} < ε
  filter_upwards [h_event, Filter.eventually_ge_atTop 3] with N hN_eps hN3
  have hN_pos : (0:ℝ) < (N:ℝ) := Nat.cast_pos.mpr (by omega)
  have hN_gt1 : (1:ℝ) < (N:ℝ) := by exact_mod_cast (show 1 < N from by omega)
  have hlogN_ge : 1 ≤ Real.log (N:ℝ) := by
    rw [Real.le_log_iff_exp_le hN_pos]
    calc Real.exp 1 ≤ 3 := by linarith [Real.exp_one_lt_d9]
      _ ≤ (N : ℝ) := by exact_mod_cast hN3
  -- ‖C·N^{-α}/logN‖ ≤ |C|·N^{-α} ≤ ‖|C|·N^{-α}‖ < ε
  calc ‖C * (N : ℝ) ^ (-α) / Real.log N‖
      = |C| * (N : ℝ) ^ (-α) / Real.log (N:ℝ) := by
        rw [norm_div, norm_mul, Real.norm_eq_abs C,
            Real.norm_eq_abs ((N:ℝ) ^ (-α)),
            abs_of_nonneg (rpow_nonneg hN_pos.le _),
            Real.norm_eq_abs (Real.log (N:ℝ)),
            abs_of_pos (Real.log_pos hN_gt1)]
    _ ≤ |C| * (N : ℝ) ^ (-α) :=
        div_le_self (mul_nonneg (abs_nonneg C) (rpow_nonneg hN_pos.le _)) hlogN_ge
    _ ≤ ‖|C| * (N : ℝ) ^ (-α)‖ := le_norm_self _
    _ < ε := hN_eps

/-- **COROLLARY**: Under RH, the truncation error → 0 as N → ∞
    for any fixed σ > 3/4.
    CLOSED: corollary of `tapered_truncation_bound_above_34` +
    `tendsto_rpow_neg_div_log`. -/
lemma tapered_truncation_tendsto_zero
    (hRH : RiemannHypothesis)
    (σ : ℝ) (hσ : 3/4 < σ) (hσ2 : σ < 2)
    (t : ℝ) :
    Filter.Tendsto (fun N : ℕ => ‖taperedTruncationError N σ t‖)
      Filter.atTop (nhds 0) := by
  -- Case split: is ζ(σ+it) = 0?
  by_cases h : ‖riemannZeta (↑σ + ↑t * I)‖ = 0
  · -- Case 1: ζ(s) = 0. Bound is 0 for all N ≥ 2, so ‖E_N‖ ≤ 0 → ‖E_N‖ = 0.
    apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds tendsto_const_nhds
    · filter_upwards with N; exact norm_nonneg _
    filter_upwards [Filter.eventually_ge_atTop 2] with N hN
    have hbd := tapered_truncation_bound_above_34 hRH σ hσ hσ2 N hN t
    simp only [h, ite_true] at hbd
    exact le_antisymm hbd (norm_nonneg _) ▸ le_refl (0 : ℝ)
  · -- Case 2: ζ(s) ≠ 0. Bound is 42·N^{3/4-σ}/logN → 0.
    have hα : 0 < σ - 3/4 := by linarith
    have h_conv : Filter.Tendsto (fun N : ℕ => 42 * (N : ℝ) ^ ((3:ℝ)/4 - σ) / Real.log N)
        Filter.atTop (nhds 0) := by
      have := tendsto_rpow_neg_div_log 42 (σ - 3/4) hα
      convert this using 2
      simp only [neg_sub]
    apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds h_conv
    · filter_upwards with N; exact norm_nonneg _
    filter_upwards [Filter.eventually_ge_atTop 2] with N hN
    have hbd := tapered_truncation_bound_above_34 hRH σ hσ hσ2 N hN t
    simp [h] at hbd
    exact hbd

-- ════════════════════════════════════════════════
-- §3. THE L² BOUND ON A VERTICAL LINE
-- ════════════════════════════════════════════════

/-- **DEPRECATED (ORPHANED)**: This lemma is not on the active proof path.
    The forward direction `baez_duarte_forward_proved` is proved via
    `rh_implies_bd_convergence_proved` (BDBridge.lean), which uses the
    Vasyunin crown chain instead of the Mellin L² approach.

    Retained for documentation of the alternative Mellin proof strategy.

    Under RH, the L² integral of the Mellin transform
    of the BD residual on the shifted line σ = 1 tends to zero.

    ∫_{-T}^{T} |M[r_N](1+it)|² dt → 0 as N → ∞

    This uses:
    1. The Mellin factorization: M[r_N](s) = (ζ(s)/s) · E_N(s)
    2. Littlewood Maneuver: |ζ(s)/s| ≤ C·|t|^A on σ ≥ 1
    3. Tapered truncation: |E_N(1+it)| ≤ C·N^{-1/4}/logN
    4. Integration: ∫|ζ/s|²·|E_N|² ≤ (C/log²N)·∫|t|^{2A}·... converges -/
lemma mellin_l2_integral_tendsto_zero
    (hRH : RiemannHypothesis) :
    Filter.Tendsto (fun N : ℕ =>
      ∫ t in (-(N:ℝ))..N,
        ‖(riemannZeta (1 + ↑t * I) / (1 + ↑t * I)) *
          taperedTruncationError N 1 t‖ ^ 2)
      Filter.atTop (nhds 0) := by
  -- Strategy: bound ‖(ζ/s)·E_N‖² ≤ ‖ζ/s‖² · ‖E_N‖²
  -- Then ‖E_N(1,t)‖ ≤ 42·N^{-1/4}/logN (uniform in t, from #1 at σ=1)
  -- So the integral ≤ (42·N^{-1/4}/logN)² · ∫‖ζ/s‖² dt
  -- The integral ∫_{-N}^{N} ‖ζ/s‖² is O(N^{1+ε}) by Littlewood
  -- Combined: O(N^{1+ε} · N^{-1/2}/log²N) → 0
  -- This requires careful integration bounds.
  sorry -- DEPRECATED: Orphaned, bypassed by MellinCrown.lean
  -- NOTE: This sorry is NOT on the active proof path (ORPHANED).
  -- Superseded by `rh_implies_bd_convergence_mellin` (MellinCrown.lean, PROVED).
  -- Closing this sorry would require:
  --   1. Formalizing ∫|ζ(σ+it)/s|² dt as O(T^{1+ε}) (Littlewood growth)
  --   2. Dominated convergence for products of L² and L∞ bounds
  --   3. Formalizing the Mellin factorization M[r_N] = (ζ/s)·E_N
  -- This is substantial (~500 lines) and not needed since MellinCrown.lean
  -- provides the same result via a different approach.

-- ════════════════════════════════════════════════
-- §4. THE L²(0,1) BOUND VIA WEIGHT SUBSTITUTION
-- ════════════════════════════════════════════════

/-- **DEPRECATED (ORPHANED)**: This lemma is not on the active proof path.
    The forward direction `baez_duarte_forward_proved` uses an existential
    witness from the Vasyunin crown (via `rh_implies_bd_convergence_proved`)
    instead of this specific-witness bound.

    Retained for documentation of the direct L² bound strategy.

    The Fejér-Möbius weights produce a BD residual whose L² norm
    is controlled at rate O(N^{-1/4}/logN).

    Uses the PROVED identity:
      ∫₀¹ (1 - bdLinComb N v x)² = 1 - 2·bᵀv + vᵀGv
    from `bd_l2_error_eq_quad_error` (Cathedral/NymanBeurling/BDBridge.lean).

    Reduces to bounding the quadratic error:
      1 - 2·(Σ vₖ·bₖ) + vᵀGv ≤ 42·N^{-1/4}/logN

    which requires:
    - bᵀv ≈ 1 (PROVED: moebius_dot_product_approx_one_uniform_34)
    - vᵀGv ≈ 1 (requires covariance bound + variance identity) -/
lemma fejer_residual_l2_bound
    (hRH : RiemannHypothesis)
    (N : ℕ) (hN : 3 ≤ N) :
    ∫ x in (0:ℝ)..1, (1 - bdLinComb N (moebiusWeightVec N) x) ^ 2 ≤
      42 * (N : ℝ) ^ (-(1:ℝ)/4) / Real.log N := by
  -- Step 1: Use the PROVED L² ↔ quadratic form identity
  -- ∫(1-f)² = 1 - 2·bᵀv + vᵀGv
  -- This identity is proved in BDBridge.lean via integral linearity
  -- and the Vasyunin gram entry integrals.
  --
  -- The remaining analytical content is:
  --   1 - 2·(Σ vₖ·bₖ) + vᵀGv ≤ 42·N^{-1/4}/logN
  -- where:
  --   |1 - bᵀv| ≤ C_dot/logN    (PROVED: moebius_dot_product_approx_one_uniform_34)
  --   vᵀGv ≈ 1                   (needs covariance decomposition)
  --
  -- Under RH, the Mertens bound |M(x)| ≤ C·x^{3/4} gives:
  --   bᵀv = 1 + O(N^{-1/4}/logN)  [Abel summation, PROVED]
  --   vᵀGv = 1 + O(1/logN)         [covariance bound, Abel summation]
  -- Combined: 1 - 2(1+ε₁) + (1+ε₂) = ε₂ - 2ε₁ = O(1/logN)
  -- Since N^{-1/4}/logN ≤ 1/logN, the bound follows.
  sorry -- DEPRECATED: Orphaned, bypassed by DirectMellinBound.lean
  -- NOTE: This sorry is NOT on the active proof path (ORPHANED).
  -- Superseded by `rh_l2_decay_clean` (DirectMellinBound.lean, PROVED)
  -- which gives ∫|1-f|² ≤ C_l2/logN using the same weights.
  -- This lemma asks for the STRONGER rate O(N^{-1/4}/logN), which
  -- would require formalizing the full covariance decomposition.
  -- The 1/logN rate from rh_l2_decay_clean suffices for all exports.

-- ════════════════════════════════════════════════
-- §5. THE FORWARD DIRECTION — GRADUATING baez_duarte_forward
-- ════════════════════════════════════════════════

/-- **THE THEOREM**: Under RH, the BD basis approximates 1 in L²(0,1).

    PROVED via the Vasyunin crown chain:
    1. `bd_witness_l2_error_decay_proved` (WitnessDecayProved.lean, PROVED):
       ∃ C > 0, ∃ N₀, ∀ N ≥ N₀, ∃ v, 1 - 2bᵀv + vᵀGv ≤ C/logN
    2. `bd_l2_error_eq_quad_error` (BDBridge.lean, PROVED):
       ∫(1-f)² = 1 - 2bᵀv + vᵀGv
    3. C/logN → 0 (standard calculus, PROVED)

    This bypasses fejer_residual_l2_bound (sorry #5) and
    mellin_l2_integral_tendsto_zero (sorry #4) entirely,
    using the Vasyunin crown's existential witness instead. -/
theorem baez_duarte_forward_proved :
    RiemannHypothesis →
    ∀ ε > 0, ∃ N₀ : ℕ, ∀ N ≥ N₀, ∃ v : Fin (N - 1) → ℝ,
      ∫ x in (0:ℝ)..1, (1 - bdLinComb N v x) ^ 2 < ε :=
  rh_implies_bd_convergence_proved

end Cathedral.ZeroAxiom
