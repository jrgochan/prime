/-
  Cathedral/Robin/BaseCases.lean

  ## Lagarias Base Case Verification

  Proves Lagarias's inequality for n = 1:
    σ(1) = 1 ≤ H₁ + exp(H₁)·log(H₁) = 1 + e·0 = 1
-/

import Cathedral.Robin.Defs
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.Harmonic.Defs

open Real ArithmeticFunction

-- ════════════════════════════════════════════════
-- LAGARIAS BASE CASE
-- ════════════════════════════════════════════════

/-- **THEOREM (PROVED)**: Lagarias holds for n = 1.

    σ(1) = 1, H₁ = 1, log(1) = 0, exp(1)·0 = 0.
    So σ(1) ≤ 1 + 0 = 1. Exact equality. -/
theorem lagarias_base_case :
    (sumOfDivisors 1 : ℝ) ≤ harmonicR 1 + exp (harmonicR 1) * log (harmonicR 1) := by
  unfold sumOfDivisors harmonicR
  have h_sigma : ((sigma 1) 1 : ℝ) = 1 := by norm_num
  have h_harmonic : (harmonic 1 : ℝ) = 1 := by norm_num
  rw [h_sigma, h_harmonic, log_one, mul_zero, add_zero]

-- NOTE: Lagarias for n = 2,3,5,7 is proved in PrimeBounds.lean
-- via lagarias_for_primes, since these are all prime.

/-- σ(1) = 1 (unit has only itself as divisor). -/
theorem sumOfDivisors_one : sumOfDivisors 1 = 1 := by
  unfold sumOfDivisors; norm_num

/-- σ(2) = 3 (divisors: 1, 2). -/
theorem sumOfDivisors_two : sumOfDivisors 2 = 3 := by
  unfold sumOfDivisors; native_decide

/-- σ(6) = 12 (6 is the first perfect number: 1+2+3+6 = 12 = 2·6). -/
theorem sumOfDivisors_six : sumOfDivisors 6 = 12 := by
  unfold sumOfDivisors; native_decide

/-- σ(28) = 56 (28 is the second perfect number: 1+2+4+7+14+28 = 56 = 2·28). -/
theorem sumOfDivisors_twentyeight : sumOfDivisors 28 = 56 := by
  unfold sumOfDivisors; native_decide

/-- σ(5040) = 19344 — The last Robin counterexample.
    5040 = 7! = 2⁴·3²·5·7 is the largest n for which σ(n) ≥ eᵞ·n·log(log(n)). -/
theorem sumOfDivisors_5040 : sumOfDivisors 5040 = 19344 := by
  unfold sumOfDivisors; native_decide

/-- σ(3) = 4 (divisors: 1, 3). -/
theorem sumOfDivisors_three : sumOfDivisors 3 = 4 := by
  unfold sumOfDivisors; native_decide

/-- σ(12) = 28 (divisors: 1, 2, 3, 4, 6, 12). -/
theorem sumOfDivisors_twelve : sumOfDivisors 12 = 28 := by
  unfold sumOfDivisors; native_decide

/-- σ(496) = 992 (496 is the third perfect number: σ(n) = 2n). -/
theorem sumOfDivisors_496 : sumOfDivisors 496 = 992 := by
  unfold sumOfDivisors; native_decide

/-- 6 is perfect: σ(6) = 2·6. -/
theorem perfect_six : sumOfDivisors 6 = 2 * 6 := by
  unfold sumOfDivisors; native_decide

/-- 28 is perfect: σ(28) = 2·28. -/
theorem perfect_twentyeight : sumOfDivisors 28 = 2 * 28 := by
  unfold sumOfDivisors; native_decide

/-- 496 is perfect: σ(496) = 2·496. -/
theorem perfect_496 : sumOfDivisors 496 = 2 * 496 := by
  unfold sumOfDivisors; native_decide

-- ════════════════════════════════════════════════
-- AUDIT
-- ════════════════════════════════════════════════

-- This file has:
--   ZERO sorry
--   ZERO axioms
--   6 PROVED theorems:
--     ✅ lagarias_base_case        — σ(1) ≤ H₁ + exp(H₁)·log(H₁)
--     ✅ sumOfDivisors_one         — σ(1) = 1
--     ✅ sumOfDivisors_two         — σ(2) = 3
--     ✅ sumOfDivisors_six         — σ(6) = 12  (perfect number!)
--     ✅ sumOfDivisors_twentyeight — σ(28) = 56  (perfect number!)
--     ✅ sumOfDivisors_5040        — σ(5040) = 19344 (Robin boundary)
